using Microsoft.EntityFrameworkCore;
using ProjetStageKhadija.Models;

namespace ProjetStageKhadija.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<FinancialProduct> FinancialProducts { get; set; }
    }
}