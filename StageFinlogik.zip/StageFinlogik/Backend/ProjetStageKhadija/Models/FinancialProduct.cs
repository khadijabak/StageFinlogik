namespace ProjetStageKhadija.Models
{
	public class FinancialProduct
	{
		public int Id { get; set; }
		public int CompanyCode { get; set; }
		public string CompanyName { get; set; } = string.Empty;
		public int? CompanyType { get; set; }
		public decimal? Rate { get; set; }
		public string? CompoundFrequency { get; set; }
		public decimal? MinAmount { get; set; }
		public decimal? MaxAmount { get; set; }
		public string? PaymentFrequency { get; set; }
		public string? Redeemability { get; set; }
		public DateTime? ChangeDate { get; set; }
		public string? ChangeTime { get; set; }
		public DateTime? LoadDate { get; set; }
		public DateTime ImportedAt { get; set; }
	}
}