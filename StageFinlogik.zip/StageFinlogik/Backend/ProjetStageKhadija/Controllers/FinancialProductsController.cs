using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetStageKhadija.Data;

namespace ProjetStageKhadija.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FinancialProductsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FinancialProductsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var products = await _context.FinancialProducts.ToListAsync();
            return Ok(products);
        }
    }
}