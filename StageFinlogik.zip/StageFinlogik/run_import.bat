cd C:\Users\DELL\Desktop\StageFinlogik\Backend\DataImporter
dotnet publish -c Release -r win-x64 --self-contained false -o C:\Users\DELL\Desktop\StageFinlogik\DataImporterApp