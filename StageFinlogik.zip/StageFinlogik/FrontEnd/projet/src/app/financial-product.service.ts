import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FinancialProduct } from './financial-product.model';

@Injectable({ providedIn: 'root' })
export class FinancialProductService {
  // Adapte l'URL selon le port réel de ton API .NET (ex: https://localhost:5261)
  private readonly apiUrl = 'http://localhost:5158/api/financialproducts';

  constructor(private http: HttpClient) {}

  getAll(): Observable<FinancialProduct[]> {
    return this.http.get<FinancialProduct[]>(this.apiUrl);
  }
}
