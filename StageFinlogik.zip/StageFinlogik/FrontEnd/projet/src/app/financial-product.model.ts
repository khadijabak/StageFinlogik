export type CompoundFrequency = 'A' | 'S' | 'Q' | 'M' | 'W' | 'D' | 'N';
export type PaymentFrequency = 'A' | 'S' | 'Q' | 'M' | 'W' | 'D' | 'E';
export type Redeemability = 'C' | 'N' | 'R';
export type CompanyType = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export interface FinancialProduct {
  id: number;
  companyName: string;
  companyType?: CompanyType;
  rate: number;
  compoundFrequency: CompoundFrequency;
  paymentFrequency: PaymentFrequency;
  minAmount: number;
  maxAmount: number; // -1 = unlimited
  redeemability: Redeemability;
}

export const COMPOUND_LABELS: Record<CompoundFrequency, string> = {
  A: 'Annually',
  S: 'Semi-annually',
  Q: 'Quarterly',
  M: 'Monthly',
  W: 'Weekly',
  D: 'Daily',
  N: 'Not compounded',
};

export const PAYMENT_LABELS: Record<PaymentFrequency, string> = {
  A: 'Annually',
  S: 'Semi-annually',
  Q: 'Quarterly',
  M: 'Monthly',
  W: 'Weekly',
  D: 'Daily',
  E: 'End of term',
};

export const REDEEMABILITY_LABELS: Record<Redeemability, string> = {
  C: 'Cashable',
  N: 'Non-redeemable',
  R: 'Redeemable',
};

export const COMPANY_TYPE_LABELS: Record<CompanyType, string> = {
  1: 'Bank',
  2: 'Trust Company',
  3: 'Insurance Company',
  4: 'Credit Union',
  5: 'Savings and Loan',
  6: 'Mortgage Corporation',
  7: 'Broker',
  8: 'Mutual Fund Company',
  9: 'Other',
};
export const COMPANY_LOGOS: Record<string, string> = {
  'Sable Savings & Mort': 'sable-savings-mort.png',
  'Aurora Trust Bank': 'aurora-trust-bank.png',
  'Cedarbrook Financial': 'cedarbrook-financial.png',
  'Northgate Mortgage Corp.': 'northgate-mortgage-corp.png',
  'Northgate Trust': 'northgate-trust.png',
  'Sterling National Bank': 'sterling-national-bank.png',
  'Harborview Bank Agt': 'harborview-bank.png',
  'Pinecrest Financial': 'pinecrest-financial.png',
  'Fairwind Bank': 'fairwind-bank.png',
  'Meridian Trustee Co.': 'meridian-trustee-co.png',
  'Redstone Western Bank': 'redstone-western-bank.png',
  'Coastal Summit Svgs Agt.': 'coastal-summit-svgs.png',
  'Ashford Bank': 'ashford-bank.png',
  'Willowbrook Bank': 'willowbrook-bank.png',
  'Union Ridge Credit Union': 'union-ridge-credit-union.png',
  'Lakeside Community CU': 'lakeside-community-cu.png',
  'Dominion Bank of Canada': 'dominion-bank-of-canada.png',
  'Kingsley Trust Agent Servic': 'kingsley-trust.png',
  'Brightpath Bank': 'brightpath-bank.png',
  'Elmwood Bank - Agent': 'elmwood-bank.png',
  'Cascade Trust Company-Agent': 'cascade-trust-company.png',
  'Frontier Credit Union': 'frontier-credit-union.png',
  'Vantage Point Bank': 'vantage-point-bank.png',
  'Vantage Point Trust': 'vantage-point-trust.png',
  'Granite Trust Agt. Ser': 'granite-trust.png',
  'Chartwell Bank Agent Ser': 'chartwell-bank.png',
  'Chartwell Trust Agent S.': 'chartwell-trust.png',
  'Beacon Hill Bank': 'beacon-hill-bank.png',
  'Summit Mtge Corp. Agt.': 'summit-mtge-corp.png',
  'Pathway Capital Bank': 'pathway-capital-bank.png',
  'Silverline (Pac&WestBank)': 'silverline.png',
};