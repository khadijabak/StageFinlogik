import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  FinancialProduct,
  CompoundFrequency,
  PaymentFrequency,
  Redeemability,
  COMPOUND_LABELS,
  PAYMENT_LABELS,
  REDEEMABILITY_LABELS,
} from './financial-product.model';
import { FinancialProductService } from './financial-product.service';
import { COMPANY_LOGOS } from './financial-product.model';
type ViewMode = 'list' | 'grid';
type CompoundFilter = '' | CompoundFrequency;
type PaymentFilter = '' | PaymentFrequency;
type LiquidityFilter = '' | Redeemability;

interface ContactForm {
  firstName: string;
  lastName: string;
  email: string;
}
@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
})

export class ProductsComponent implements OnInit {
  products: FinancialProduct[] = [];
  loading = true;
  error = false;

  viewMode: ViewMode = 'list';

  // --- Filtres instantanés ---
  searchTerm = '';
  liquidityFilter: LiquidityFilter = '';
  compoundFilter: CompoundFilter = '';
  paymentFilter: PaymentFilter = '';

  // --- Filtres numériques : valeurs en cours de saisie (pas encore appliquées) ---
  draftRate: number | null = null;
  draftMinAmount: number | null = null;
  draftMaxAmount: number | null = null;

  // --- Filtres numériques : valeurs réellement appliquées ---
  appliedRate: number | null = null;
  appliedMinAmount: number | null = null;
  appliedMaxAmount: number | null = null;

  // --- Pagination ---
  currentPage = 1;
  pageSize = 12;



    // --- Calculatrice d'investissement ---
  investmentAmount: number | null = null;
  years = 1;
  calculationApplied = false;
  appliedInvestmentAmount: number | null = null;
  appliedYears = 1;

    // --- Formulaires de contact (un par produit, indexé par id) ---
  contactForms: Record<number, ContactForm> = {};

  readonly compoundLabels = COMPOUND_LABELS;
  readonly paymentLabels = PAYMENT_LABELS;
  readonly redeemabilityLabels = REDEEMABILITY_LABELS;
  private readonly avatarColors = [
  '#2563eb', '#059669', '#d97706', '#dc2626',
  '#7c3aed', '#0891b2', '#db2777', '#65a30d',
];

  constructor(private productService: FinancialProductService) {}

 
getContactForm(productId: number): ContactForm {
  if (!this.contactForms[productId]) {
    this.contactForms[productId] = { firstName: '', lastName: '', email: '' };
  }
  return this.contactForms[productId];
}

sendContact(product: FinancialProduct): void {
  const form = this.getContactForm(product.id);
  console.log('Contact request sent to', product.companyName, form);
  alert(`Your message to ${product.companyName} has been sent.`);
  this.contactForms[product.id] = { firstName: '', lastName: '', email: '' };
}  
getLogoUrl(companyName: string): string | null {
  const fileName = COMPANY_LOGOS[companyName];
  return fileName ? `assets/logos/${fileName}` : null;
}
calculate(): void {
  if (this.investmentAmount == null || this.years == null) {
    return; // ne fait rien tant que les deux champs ne sont pas remplis
  }
  this.appliedInvestmentAmount = this.investmentAmount;
  this.appliedYears = this.years;
  this.calculationApplied = true;
}
onCalculatorInputChange(): void {
  this.calculationApplied = false;
}
getTotalReturn(product: FinancialProduct): number | null {
  if (this.appliedInvestmentAmount == null || product.rate == null) {
    return null;
  }
  return this.appliedInvestmentAmount * Math.pow(1 + product.rate / 100, this.appliedYears);
}

formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
}

  getInitial(name: string): string {
  return name.trim().charAt(0).toUpperCase();
}

  getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % this.avatarColors.length;
  return this.avatarColors[index];
}
ngOnInit(): void {
  this.productService.getAll().subscribe({
    next: (data) => {
      this.products = data
        .filter((p) => p.rate != null && p.rate > 0)
        .sort((a, b) => a.rate - b.rate);
      this.loading = false;
    },
    error: () => {
      this.error = true;
      this.loading = false;
    },
  });
}

  setViewMode(mode: ViewMode): void {
    this.viewMode = mode;
  }

  onFilterChange(): void {
    this.currentPage = 1;
  }

  applyFilters(): void {
    this.appliedRate = this.draftRate;
    this.appliedMinAmount = this.draftMinAmount;
    this.appliedMaxAmount = this.draftMaxAmount;
    this.currentPage = 1;
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.liquidityFilter = '';
    this.compoundFilter = '';
    this.paymentFilter = '';
    this.draftRate = null;
    this.draftMinAmount = null;
    this.draftMaxAmount = null;
    this.appliedRate = null;
    this.appliedMinAmount = null;
    this.appliedMaxAmount = null;
    this.currentPage = 1;
  }

  get filteredProducts(): FinancialProduct[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.products.filter((p) => {
      const hasRate = p.rate != null;
      const matchesSearch = !term || p.companyName.toLowerCase().includes(term);
      const matchesLiquidity = !this.liquidityFilter || p.redeemability === this.liquidityFilter;
      const matchesCompound = !this.compoundFilter || p.compoundFrequency === this.compoundFilter;
      const matchesPayment = !this.paymentFilter || p.paymentFrequency === this.paymentFilter;

      const matchesRate =
        this.appliedRate == null || (p.rate != null && p.rate <= this.appliedRate);

      const matchesMin =
        this.appliedMinAmount == null ||
        (p.minAmount != null && p.minAmount === this.appliedMinAmount);

      const matchesMax =
        this.appliedMaxAmount == null ||
        (p.maxAmount != null && p.maxAmount === this.appliedMaxAmount);

      return (
        hasRate &&
        matchesSearch &&
        matchesLiquidity &&
        matchesCompound &&
        matchesPayment &&
        matchesRate &&
        matchesMin &&
        matchesMax
      );
    });
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.filteredProducts.length / this.pageSize));
  }

  get paginatedProducts(): FinancialProduct[] {
    const start = (this.currentPage - 1) * this.pageSize;
    return this.filteredProducts.slice(start, start + this.pageSize);
  }

  get rangeStart(): number {
    if (this.filteredProducts.length === 0) return 0;
    return (this.currentPage - 1) * this.pageSize + 1;
  }

  get rangeEnd(): number {
    return Math.min(this.currentPage * this.pageSize, this.filteredProducts.length);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  previousPage(): void {
    this.goToPage(this.currentPage - 1);
  }

  nextPage(): void {
    this.goToPage(this.currentPage + 1);
  }

  formatAmount(value: number): string {
    if (value === -1) {
      return 'No limit';
    }
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
  }
}